package com.phisher98

import com.fasterxml.jackson.annotation.JsonProperty
import com.lagradost.cloudstream3.CommonActivity.activity
import com.lagradost.cloudstream3.DubStatus
import com.lagradost.cloudstream3.HomePageList
import com.lagradost.cloudstream3.HomePageResponse
import com.lagradost.cloudstream3.LoadResponse
import com.lagradost.cloudstream3.LoadResponse.Companion.addAniListId
import com.lagradost.cloudstream3.LoadResponse.Companion.addKitsuId
import com.lagradost.cloudstream3.LoadResponse.Companion.addMalId
import com.lagradost.cloudstream3.MainAPI
import com.lagradost.cloudstream3.MainPageRequest
import com.lagradost.cloudstream3.Score
import com.lagradost.cloudstream3.SearchResponse
import com.lagradost.cloudstream3.SearchResponseList
import com.lagradost.cloudstream3.ShowStatus
import com.lagradost.cloudstream3.SubtitleFile
import com.lagradost.cloudstream3.newSubtitleFile
import com.lagradost.cloudstream3.TvType
import com.lagradost.cloudstream3.addDate
import com.lagradost.cloudstream3.addEpisodes
import com.lagradost.cloudstream3.app
import com.lagradost.cloudstream3.mainPageOf
import com.lagradost.cloudstream3.mapper
import com.lagradost.cloudstream3.newAnimeLoadResponse
import com.lagradost.cloudstream3.newAnimeSearchResponse
import com.lagradost.cloudstream3.newEpisode
import com.lagradost.cloudstream3.newHomePageResponse
import com.lagradost.cloudstream3.newMovieLoadResponse
import com.lagradost.cloudstream3.runAllAsync
import com.lagradost.cloudstream3.syncproviders.AccountManager
import com.lagradost.cloudstream3.syncproviders.SyncIdName
import com.lagradost.cloudstream3.syncproviders.SyncRepo
import com.lagradost.cloudstream3.syncproviders.providers.AniListApi.CoverImage
import com.lagradost.cloudstream3.syncproviders.providers.AniListApi.LikePageInfo
import com.lagradost.cloudstream3.syncproviders.providers.AniListApi.RecommendationConnection
import com.lagradost.cloudstream3.syncproviders.providers.AniListApi.SeasonNextAiringEpisode
import com.lagradost.cloudstream3.syncproviders.providers.AniListApi.Title
import com.lagradost.cloudstream3.toNewSearchResponseList
import com.lagradost.cloudstream3.utils.AppUtils
import com.lagradost.cloudstream3.utils.AppUtils.toJson
import com.lagradost.cloudstream3.utils.ExtractorLink
import com.lagradost.nicehttp.RequestBodyTypes
import com.phisher98.StreamPlay.Companion.anilistAPI
import com.phisher98.StreamPlay.Companion.malsyncAPI
import com.phisher98.StreamPlayExtractor.invokeAnichi
import com.phisher98.StreamPlayExtractor.invokeAnikage
import com.phisher98.StreamPlayExtractor.invokeAnineko
import com.phisher98.StreamPlayExtractor.invokeAnimepahe
import com.phisher98.StreamPlayExtractor.invokeAnimetosho
import com.phisher98.StreamPlayExtractor.invokeAnimex
import com.phisher98.StreamPlayExtractor.invokeAnizone
import com.phisher98.StreamPlayExtractor.invokeHianime
import com.phisher98.StreamPlayExtractor.invokeKickAssAnime
import com.phisher98.StreamPlayExtractor.invokeReAnime
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.Calendar

class StreamPlayAnime : MainAPI() {
    override var name = "StreamPlay-Anime [Backup]"
    override var mainUrl = "https://anilist.co"
    override var supportedTypes = setOf(TvType.Anime, TvType.AnimeMovie, TvType.OVA)
    override var lang = "en"
    override val supportedSyncNames = setOf(SyncIdName.Anilist,SyncIdName.MyAnimeList)
    override val hasMainPage = true
    override val hasQuickSearch = true
    private val repo = SyncRepo(AccountManager.aniListApi)
    private val apiUrl = "https://graphql.anilist.co"
    private val mediaLimit = 20
    private val isAdult = false
    private val headerJSON =
        mapOf("Accept" to "application/json", "Content-Type" to "application/json")

    protected fun Any.toStringData(): String {
        return mapper.writeValueAsString(this)
    }

    private suspend fun anilistAPICall(query: String): AnilistAPIResponse {
        val data = mapOf("query" to query)
        val test = app.post(apiUrl, headers = headerJSON, data = data)
        val res =
            test.parsedSafe<AnilistAPIResponse>()
                ?: throw Exception("Unable to fetch or parse Anilist api response")
        return res
    }

    private fun Media.toSearchResponse(): SearchResponse {
        val title = this.title.english ?: this.title.romaji ?: ""
        val url = "$mainUrl/anime/${this.id}"
        val posterUrl = this.coverImage.large
        val rating = this.averageScore
        return newAnimeSearchResponse(title, url, TvType.Anime) {
            this.posterUrl = posterUrl
            this.score= Score.from100(rating)
        }
    }

    private suspend fun MainPageRequest.toSearchResponseList(
        page: Int
    ): Pair<List<SearchResponse>, Boolean> {
        val res = anilistAPICall(this.data.replace("###", "$page"))
        val data =
            res.data.page?.media?.map { it.toSearchResponse() }
                ?: throw Exception("Unable to read media data")
        val hasNextPage = res.data.page.pageInfo.hasNextPage ?: false
        return data to hasNextPage
    }

    private val currentYear = Calendar.getInstance().get(Calendar.YEAR)

    override val mainPage =
        mainPageOf(
            "query (\$page: Int = ###, \$sort: [MediaSort] = [TRENDING_DESC, POPULARITY_DESC], \$isAdult: Boolean = $isAdult) { Page(page: \$page, perPage: $mediaLimit) { pageInfo { total perPage currentPage lastPage hasNextPage } media(sort: \$sort, isAdult: \$isAdult, type: ANIME) { id idMal season seasonYear format episodes chapters averageScore title { english romaji } coverImage { extraLarge large medium } synonyms nextAiringEpisode { timeUntilAiring episode } } } }" to
                    "Trending Now",
            "query (\$page: Int = ###, \$seasonYear: Int = $currentYear, \$sort: [MediaSort] = [TRENDING_DESC, POPULARITY_DESC], \$isAdult: Boolean = $isAdult) { Page(page: \$page, perPage: $mediaLimit) { pageInfo { total perPage currentPage lastPage hasNextPage } media(sort: \$sort, seasonYear: \$seasonYear, season: SPRING, isAdult: \$isAdult, type: ANIME) { id idMal season seasonYear format episodes chapters averageScore title { english romaji } coverImage { extraLarge large medium } synonyms nextAiringEpisode { timeUntilAiring episode } } } }" to
                    "Popular This Season",
            "query (\$page: Int = ###, \$sort: [MediaSort] = [POPULARITY_DESC], \$isAdult: Boolean = $isAdult) { Page(page: \$page, perPage: $mediaLimit) { pageInfo { total perPage currentPage lastPage hasNextPage } media(sort: \$sort, isAdult: \$isAdult, type: ANIME) { id idMal season seasonYear format episodes chapters averageScore title { english romaji } coverImage { extraLarge large medium } synonyms nextAiringEpisode { timeUntilAiring episode } } } }" to
                    "All Time Popular",
            "query (\$page: Int = ###, \$sort: [MediaSort] = [SCORE_DESC], \$isAdult: Boolean = $isAdult) { Page(page: \$page, perPage: $mediaLimit) { pageInfo { total perPage currentPage lastPage hasNextPage } media(sort: \$sort, isAdult: \$isAdult, type: ANIME) { id idMal season seasonYear format episodes chapters averageScore title { english romaji } coverImage { extraLarge large medium } synonyms nextAiringEpisode { timeUntilAiring episode } } } }" to
                    "Top 100 Anime",
            "Personal" to "Personal"
        )

    override suspend fun search(query: String, page: Int): SearchResponseList? {
        val res =
            anilistAPICall(
                "query (\$search: String = \"$query\") { Page(page: $page, perPage: $mediaLimit) { pageInfo { total perPage currentPage lastPage hasNextPage } media(search: \$search, isAdult: $isAdult, type: ANIME) { id idMal season seasonYear format episodes chapters title { english romaji } coverImage { extraLarge large medium } synonyms nextAiringEpisode { timeUntilAiring episode } } } }"
            )
        return res.data.page?.media?.map { it.toSearchResponse() }?.toNewSearchResponseList()
    }

    override suspend fun getMainPage(page: Int, request: MainPageRequest): HomePageResponse {
        if (request.name.contains("Personal")) {
            // Reading and manipulating personal library
            repo.authUser()
                ?: return newHomePageResponse(
                    "Login required for personal content.",
                    emptyList<SearchResponse>(),
                    false
                )
            val homePageList =
                repo.library().getOrThrow()!!.allLibraryLists.mapNotNull {
                    if (it.items.isEmpty()) return@mapNotNull null
                    val libraryName =
                        it.name.asString(activity ?: return@mapNotNull null)
                    HomePageList("${request.name}: $libraryName", it.items)
                }
            return newHomePageResponse(homePageList, false)
        } else {
            // Other new sections will be generated if toSearchResponseList() is
            // overridden
            val data = request.toSearchResponseList(page)
            return newHomePageResponse(request.name, data.first, data.second)
        }
    }

    override suspend fun load(url: String): LoadResponse {
        val id = url.removeSuffix("/").substringAfterLast("/")
        val data = anilistAPICall(
            "query (\$id: Int = $id) { Media(id: \$id, type: ANIME) { id title { romaji english } startDate { year } genres description averageScore status bannerImage coverImage { extraLarge large medium } bannerImage episodes format nextAiringEpisode { episode } airingSchedule { nodes { episode } } recommendations { edges { node { id mediaRecommendation { id title { romaji english } coverImage { extraLarge large medium } } } } } } }"
        ).data.media ?: throw Exception("Unable to fetch media details")

        val anititle = data.getTitle()
        val aniyear = data.startDate.year
        val posterurl = data.coverImage.extraLarge
        val backgroundUrl = data.bannerImage

        val anitype = if (data.format!!.contains("MOVIE", ignoreCase = true)) TvType.AnimeMovie else TvType.TvSeries
        val ids = tmdbToAnimeId(anititle, aniyear, anitype)

        val jpTitle = data.title.romaji

        val syncMetaData = app.get("https://api.ani.zip/mappings?anilist_id=${ids.id}").toString()
        val animeMetaData = parseAnimeData(syncMetaData)
        val tmdbid = animeMetaData?.mappings?.themoviedbId?.toIntOrNull()
        val kitsuid = animeMetaData?.mappings?.kitsuid

        val type = if (data.format.contains("Movie", ignoreCase = true)) TvType.Movie else TvType.TvSeries

        val logoUrl = fetchTmdbLogoUrl(
            tmdbAPI = "https://api.themoviedb.org/3",
            apiKey = "98ae14df2b8d8f8f8136499daf79f0e0",
            type = type,
            tmdbId = tmdbid,
            appLangCode = "en"
        )

        val totalEps = data.totalEpisodes()
        val anidbEidMap: Map<Int, Int> = (1..totalEps).associateWith { getAnidbEid(syncMetaData, it) ?: 0 }
        val epMetaMap: Map<Int, MetaEpisode?> = (1..totalEps).associateWith { animeMetaData?.episodes?.get(it.toString()) }

        val fallbackPoster = animeMetaData?.images?.firstOrNull()?.url ?: ""
        val fallbackTitle = animeMetaData?.titles?.get("en")
            ?: animeMetaData?.titles?.get("ja")
            ?: animeMetaData?.titles?.get("x-jat")
            ?: ""

        fun resolveTitle(epData: MetaEpisode?): String {
            val jsonTitle = epData?.title?.get("en")
                ?: epData?.title?.get("ja")
                ?: epData?.title?.get("x-jat")
                ?: fallbackTitle
            return jsonTitle.ifBlank { "Episode ${epData?.episode ?: ""}" }
        }

        val anidbEid = anidbEidMap[1] ?: 0
        val href = LinkData(
            malId = ids.idMal,
            aniId = ids.id,
            title = data.getTitle(),
            jpTitle = jpTitle,
            year = data.startDate.year,
            isAnime = true,
            anidbEid = anidbEid,
            episode = 1
        ).toStringData()

        val episodes = (1..totalEps).map { i ->
            val epData = epMetaMap[i]
            val linkData = LinkData(
                malId = ids.idMal,
                aniId = ids.id,
                title = data.getTitle(),
                jpTitle = jpTitle,
                year = data.startDate.year,
                season = 1,
                episode = i,
                isAnime = true,
                isDub = false,
                anidbEid = anidbEidMap[i] ?: 0
            ).toStringData()

            newEpisode(linkData) {
                this.season = 1
                this.episode = i
                this.name = resolveTitle(epData)
                this.posterUrl = epData?.image ?: fallbackPoster
                this.description = epData?.overview ?: "No summary available"
                this.score = Score.from10(epData?.rating)
                this.runTime = epData?.runtime
                this.addDate(epData?.airdate)
            }
        }

        val episodesDub = episodes.mapIndexed { idx, ep ->
            val i = idx + 1
            val dubLinkData = LinkData(
                malId = ids.idMal,
                aniId = ids.id,
                title = data.getTitle(),
                jpTitle = jpTitle,
                year = data.startDate.year,
                season = 1,
                episode = i,
                isAnime = true,
                isDub = true,
                anidbEid = anidbEidMap[i] ?: 0
            ).toStringData()
            ep.copy(data = dubLinkData)  // reuse all metadata, only href differs
        }

        return if (data.format.contains("Movie", ignoreCase = true)) {
            newMovieLoadResponse(data.getTitle(), url, TvType.AnimeMovie, href) {
                addAniListId(id.toInt())
                addMalId(ids.idMal)
                try { addKitsuId(kitsuid) } catch (_: Throwable) {}
                this.year = data.startDate.year
                this.plot = data.description
                this.backgroundPosterUrl = backgroundUrl ?: animeMetaData?.images?.firstOrNull { it.coverType == "Fanart" }?.url ?: data.bannerImage
                this.posterUrl = posterurl ?: data.getCoverImage() ?: animeMetaData?.images
                    ?.firstOrNull { it.coverType.equals("Poster", ignoreCase = true) }?.url
                try { this.logoUrl = logoUrl } catch (_: Throwable) {}
                this.tags = data.genres
                this.score = Score.from100(data.averageScore)
            }
        } else {
            newAnimeLoadResponse(data.getTitle(), url, TvType.Anime) {
                addAniListId(id.toInt())
                addMalId(ids.idMal)
                try { addKitsuId(kitsuid) } catch (_: Throwable) {}
                addEpisodes(DubStatus.Subbed, episodes)
                addEpisodes(DubStatus.Dubbed, episodesDub)
                try { this.logoUrl = logoUrl } catch (_: Throwable) {}
                this.year = data.startDate.year
                this.plot = data.description
                this.backgroundPosterUrl = animeMetaData?.images?.firstOrNull { it.coverType == "Fanart" }?.url ?: data.bannerImage
                this.posterUrl = data.getCoverImage() ?: animeMetaData?.images
                    ?.firstOrNull { it.coverType.equals("Poster", ignoreCase = true) }?.url
                this.tags = data.genres
                this.score = Score.from100(data.averageScore)
                this.showStatus = getStatus(data.status)
                this.recommendations = data.recommendations?.edges
                    ?.mapNotNull { edge ->
                        val recommendation = edge.node.mediaRecommendation ?: return@mapNotNull null
                        val title = recommendation.title?.english ?: recommendation.title?.romaji ?: "Unknown"
                        newAnimeSearchResponse(title, "$mainUrl/anime/${recommendation.id}", TvType.Anime).apply {
                            this.posterUrl = recommendation.coverImage?.large
                        }
                    }
            }
        }
    }

    override suspend fun loadLinks(
        data: String,
        isCasting: Boolean,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val mediaData = AppUtils.parseJson<LinkData>(data)
        val malId = mediaData.malId
        val episode = mediaData.episode
        val jpTitle = mediaData.jpTitle
        val anititle = mediaData.title
        val anidbEid = mediaData.anidbEid
        val aniid = mediaData.aniId
        //val season= jpTitle?.let { extractSeason(it) }
        val year=mediaData.year
        val malsync = app.get("$malsyncAPI/mal/anime/$malId").parsedSafe<MALSyncResponses>()?.sites
        //val zoro = malsync?.zoro
        //val zorotitle = zoro?.values?.firstNotNullOfOrNull { it["title"] }?.replace(":", " ")
        val kaasSlug = malsync?.KickAssAnime?.values?.firstNotNullOfOrNull { it["identifier"] }

        val dubStatus: String? =
            if (mediaData.season == null) "Movie"
            else if (mediaData.isDub) "DUB"
            else "SUB"

        runAllAsync(
            { invokeHianime(malId, episode, subtitleCallback, callback, dubStatus) },
            {
                malsync?.animepahe?.values?.firstNotNullOfOrNull { it["url"] }?.let {
                    invokeAnimepahe(it, episode, subtitleCallback, callback, dubStatus)
                }
            },

            { invokeAnizone(jpTitle, episode, subtitleCallback, callback, dubStatus) },
            { invokeAnikage(aniid, anititle ?: jpTitle, episode, subtitleCallback, callback, dubStatus) },
            { invokeAnichi(jpTitle, anititle, year, episode, subtitleCallback, callback, dubStatus) },
            { invokeKickAssAnime(jpTitle,kaasSlug, episode, subtitleCallback, callback, dubStatus) },
            { invokeAnimex(malId, aniid, jpTitle, episode, subtitleCallback, callback, dubStatus) },
            {
                malId?.let {
                    invokeAnimetosho(
                        subtitleCallback,
                        callback,
                        dubStatus,
                        anidbEid
                    )
                }
            },
            {
                invokeReAnime(aniid, episode, subtitleCallback, callback, dubStatus)
            },
            {
                invokeAnineko(anititle, jpTitle, episode, subtitleCallback, callback, dubStatus)
            }
        )
        return true
    }

    fun getStatus(t: String?): ShowStatus {
        return when {
            t?.contains("Returning", ignoreCase = true) == true -> ShowStatus.Ongoing
            t?.contains("RELEASING", ignoreCase = true) == true -> ShowStatus.Ongoing
            else -> ShowStatus.Completed
        }
    }

    data class AnilistAPIResponse(
        @param:JsonProperty("data") val data: AnilistData,
    ) {
        data class AnilistData(
            @param:JsonProperty("Page") val page: AnilistPage?,
            @param:JsonProperty("Media") val media: anilistMedia?,
        ) {
            data class AnilistPage(
                @param:JsonProperty("pageInfo") val pageInfo: LikePageInfo,
                @param:JsonProperty("media") val media: List<Media>,
            )
        }

        data class anilistMedia(
            @param:JsonProperty("id") val id: Int,
            @param:JsonProperty("startDate") val startDate: StartDate,
            @param:JsonProperty("episodes") val episodes: Int?,
            @param:JsonProperty("title") val title: Title,
            @param:JsonProperty("season") val season: String?,
            @param:JsonProperty("genres") val genres: List<String>,
            @param:JsonProperty("averageScore") val averageScore: Int,
            @param:JsonProperty("status") val status: String,
            @param:JsonProperty("description") val description: String?,
            @param:JsonProperty("coverImage") val coverImage: CoverImage,
            @param:JsonProperty("bannerImage") val bannerImage: String?,
            @param:JsonProperty("nextAiringEpisode") val nextAiringEpisode: SeasonNextAiringEpisode?,
            @param:JsonProperty("airingSchedule") val airingSchedule: AiringScheduleNodes?,
            @param:JsonProperty("recommendations") val recommendations: RecommendationConnection?,
            @param:JsonProperty("format") val format: String?,
        ) {
            data class StartDate(@param:JsonProperty("year") val year: Int)

            data class AiringScheduleNodes(
                @param:JsonProperty("nodes") val nodes: List<SeasonNextAiringEpisode>?
            )

            fun totalEpisodes(): Int {
                return nextAiringEpisode?.episode?.minus(1)
                    ?: episodes
                    ?: airingSchedule?.nodes?.getOrNull(0)?.episode
                    ?: 0
            }

            fun getTitle(): String {
                return title.english
                    ?: title.romaji ?: throw Exception("Unable to calculate total episodes")
            }

            fun getCoverImage(): String? {
                return coverImage.extraLarge ?: coverImage.large ?: coverImage.medium
            }
        }
    }

    data class LinkData(
        @param:JsonProperty("simklId") val simklId: Int? = null,
        @param:JsonProperty("traktId") val traktId: Int? = null,
        @param:JsonProperty("imdbId") val imdbId: String? = null,
        @param:JsonProperty("tmdbId") val tmdbId: Int? = null,
        @param:JsonProperty("tvdbId") val tvdbId: Int? = null,
        @param:JsonProperty("type") val type: String? = null,
        @param:JsonProperty("season") val season: Int? = null,
        @param:JsonProperty("episode") val episode: Int? = null,
        @param:JsonProperty("aniId") val aniId: Int? = null,
        @param:JsonProperty("malId") val malId: Int? = null,
        @param:JsonProperty("title") val title: String? = null,
        @param:JsonProperty("year") val year: Int? = null,
        @param:JsonProperty("orgTitle") val orgTitle: String? = null,
        @param:JsonProperty("isAnime") val isAnime: Boolean = false,
        @param:JsonProperty("airedYear") val airedYear: Int? = null,
        @param:JsonProperty("lastSeason") val lastSeason: Int? = null,
        @param:JsonProperty("epsTitle") val epsTitle: String? = null,
        @param:JsonProperty("jpTitle") val jpTitle: String? = null,
        @param:JsonProperty("date") val date: String? = null,
        @param:JsonProperty("airedDate") val airedDate: String? = null,
        @param:JsonProperty("isAsian") val isAsian: Boolean = false,
        @param:JsonProperty("isBollywood") val isBollywood: Boolean = false,
        @param:JsonProperty("isCartoon") val isCartoon: Boolean = false,
        @param:JsonProperty("isDub") val isDub: Boolean = false,
        @param:JsonProperty("anidbEid") val anidbEid: Int? = null,
        )

    data class Media(
        @param:JsonProperty("id") val id: Int,
        @param:JsonProperty("idMal") val idMal: Int?,
        @param:JsonProperty("season") val season: String?,
        @param:JsonProperty("seasonYear") val seasonYear: Int,
        @param:JsonProperty("format") val format: String?,
        @param:JsonProperty("averageScore") val averageScore: Int,
        @param:JsonProperty("episodes") val episodes: Int,
        @param:JsonProperty("title") val title: Title,
        @param:JsonProperty("description") val description: String?,
        @param:JsonProperty("coverImage") val coverImage: CoverImage,
        @param:JsonProperty("synonyms") val synonyms: List<String>,
        @param:JsonProperty("nextAiringEpisode") val nextAiringEpisode: SeasonNextAiringEpisode?,
    )

    private suspend fun tmdbToAnimeId(title: String?, year: Int?, type: TvType): AniIds {
        if (title.isNullOrBlank()) return AniIds(null, null)

        val query = """
        query (
          ${'$'}page: Int = 1
          ${'$'}search: String
          ${'$'}sort: [MediaSort] = [POPULARITY_DESC, SCORE_DESC]
          ${'$'}type: MediaType
          ${'$'}season: MediaSeason
          ${'$'}seasonYear: Int
          ${'$'}format: [MediaFormat]
        ) {
          Page(page: ${'$'}page, perPage: 20) {
            media(
              search: ${'$'}search
              sort: ${'$'}sort
              type: ${'$'}type
              season: ${'$'}season
              seasonYear: ${'$'}seasonYear
              format_in: ${'$'}format
            ) {
              id
              idMal
            }
          }
        }
    """.trimIndent()

        val variables = mutableMapOf(
            "search" to title,
            "sort" to listOf("SEARCH_MATCH"),
            "type" to "ANIME",
            "format" to listOf(
                if (type == TvType.AnimeMovie) "MOVIE" else "TV",
                "ONA",
                "OVA"
            )
        )

        val data = mapOf(
            "query" to query,
            "variables" to variables
        ).toJson().toRequestBody(RequestBodyTypes.JSON.toMediaTypeOrNull())

        val res = app.post(anilistAPI, requestBody = data)
            .parsedSafe<AniSearch>()
            ?.data
            ?.let { it.Page?.media ?: it.media }
            ?.firstOrNull()

        return AniIds(res?.id, res?.idMal)
    }

    private fun extractSeason(title: String): Int? {
        val regex = Regex("""(?i)(?:season\s*(\d+)|(\d+)(?:st|nd|rd|th)?\s*season)""")
        val match = regex.find(title)
        val seasonStr = match?.groups?.get(1)?.value ?: match?.groups?.get(2)?.value ?: "1"
        return seasonStr.toIntOrNull()
    }
}
