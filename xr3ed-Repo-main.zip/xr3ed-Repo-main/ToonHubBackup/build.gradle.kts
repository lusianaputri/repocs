// use an integer for version numbers
version = 10


cloudstream {
    // All of these properties are optional, you can safely remove them

    description = "ToonHub4u Multi Language"
    language    = "id"
    authors = listOf("sad25kag")

    /**
    * Status int as the following:
    * 0: Down
    * 1: Ok
    * 2: Slow
    * 3: Beta only
    * */
    status = 1 // will be 3 if unspecified

    // List of video source types. Users are able to filter for extensions in a given category.
    // You can find a list of available types here:
    // https://recloudstream.github.io/cloudstream/html/app/com.lagradost.cloudstream3/-tv-type/index.html
    tvTypes = listOf("AnimeMovie","Anime","Cartoon")
    iconUrl="https://toonhub4u.co/wp-content/uploads/2024/02/Untitled.png"

    isCrossPlatform = false
}
